<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection, 'admin');

/* Updating Data*/
if(isset($_POST['updatedata']))
    {   
        $id = $_POST['update_id'];
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $course = $_POST['course'];
        $contact = $_POST['contact'];

        $query = "UPDATE student SET fname='$fname', lname='$lname', course='$course', contact=' $contact',modifiedDate=now() WHERE id='$id'  ";
        $query_run = mysqli_query($connection, $query);

        /* Update Message */
        if($query_run)
            {
                echo '<script> alert("Data Updated"); </script>';
                header("Location:Students.php");
            }
        else
            {
                echo '<script> alert("Data Not Updated"); </script>';
            }
    }
?>