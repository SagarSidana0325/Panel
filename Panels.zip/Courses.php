
<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Courses</title>
    <link rel="stylesheet" href="css/theme.css">

    <!-- My JS -->
    <script src="js/theme.js"></script>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" 
    rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="js/observers.js"></script>
      <script>
$(document).ready(function(){
  $("#theme").click(function(){
    $("#mode").toggleClass("darkgrey");
    $("#mode").toggleClass("text-light");
    $("#ul").toggleClass("bg-dark");
    $("#theme").toggleClass("text-light");
    $("#active").toggleClass("bg-dark");
  });
});
</script>
    
 <style type="text/css">
     .black{
  position:fixed;
  top:0;
  background:#333;
  color: white;
  width:100%;
  height:50px;
  
}
.darkgrey {
  background-color:#282828;
}

.bg-green{
background-color: mediumseagreen;
}
.black ul{
  list-style-type:none;
  padding:0;
}

.black ul li{
  display:inline-block;
  width:100px;
  color:red;
}

.blue{
  position:fixed;
  top:0;
  background:blue;
  width:100%;
  height:50px;
}
 </style>
 <script type="text/javascript">
     
$(document).ready(function(){
  $(window).scroll(function(){
    var scroll = $(window).scrollTop();
      if (scroll > 150) {
        $(".black").css("background" , "Mediumseagreen");
      }

      else{
          $(".black").css("background" , "#333");   
      }
  })
})
 </script> 
 <script src="js/theme.js"></script>
 <!-- PreLoader -->
<style type="text/css">
    

.loader-container{
    width: 100%;
    height: 100vh;
    background-color: black;
    position: fixed;
    display: flex;
    align-items: center;
    justify-content: center;
}

.loader{
    width: 50px;
    height: 50px;
    border: 5px solid;
    color: #3498db;
    border-radius: 50%;
    border-top-color: transparent;
    animation: loader 5.2s linear infinite;
}

@keyframes loader{
    25%{
        color: #2ecc71;
    }
    50%{
        color: #f1c40f;
    }
    75%{
        color: #e74c3c;
    }
    to{
        transform: rotate(360deg);
    }
}
</style>
 <script>
        $(window).on("load",function(){
            $(".loader-container").fadeOut(2000);
        });
    </script>
</head>
<body id="page-top">
    <div class="loader-container">
        <div class="loader"></div>
    </div>
<!-- Page Wrapper -->
<div id="mode" class="darkgrey text-light" >
    <!-- Sidebar -->
    <ul id="ul" class="navbar-nav  bg-green bg-dark sidebar sidebar-dark accordion fixed-top" id="accordionSidebar">
        <!-- Sidebar - Brand -->
        <a  class="sidebar-brand d-flex align-items-center text-light  justify-content-center" href="panel.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3 ">
                <h5>Welcome</h5>
            </div>
        </a>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">
        <!-- Nav Item - Dashboard -->
        <li class="nav-item active"> 
            <a class="nav-link " href="panel.php" s>
                <i class="fas fa-fw fa-home" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Home</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Teachers.php">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span><font style="font-size: 18px;">Teachers</font></span>
            </a>
        </li>
        <li class="nav-item active"> 
            <a class="nav-link" href="Students.php">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Students</font>
                </span>
            </a>
        </li>
        <!-- Nav Item - Utilities Collapse Menu -->
        <li class="nav-item active">
            <a class="nav-link collapsed" href="Schedule.php" >
                <i class="fas fa-fw fa-calendar" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Schedule</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a  class="nav-link" href="Courses.php" id="active"  style="background-color:mediumseagreen;">
                <i class="fas fa-fw fa-graduation-cap" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Courses</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <li class="nav-item active"> 
            <a class="nav-link" href="index.php">
                <i class="fas fa-fw fa-sign-out-alt" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Logout</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
    </ul>
    <!-- End of Sidebar -->
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="margin-left: 220px;">
    <!-- Main Content -->
    <!-- Topbar -->
     <nav class="navbar black fixed-top navbar-expand navbar-light topbar mb-4 static-top shadow" style="margin-left: 224px;"> 
                <ul>
                    <li><h3 align="left" class="text-light" style="width:1000px"><b>Admin Panel</b></h3></li>
                    <li style="margin-top:30px;"><h3 align="right" class="text-light" style="width:1000px"><font style="font-size:12px"><i id="theme" class="fas fa-sun fa-3x theme_icon "  ></i></font></h3>
                    </li>
                </ul>
                
            </nav>
    <br><br><br>
    <div align="center">
        <h2 align="center" class="text-success"><b>Undergraduate Courses</b></h2>
        <br>
        <!--Buttons-->
        <div class="row">
            <div class="col" align="right" style="padding-right:20px;"  >
                <a href="#bca">
                    <button type="button" class="btn btn-danger shadow-sm" style="font-size:24px">BCA</button>
                </a>
            </div>
            <div class="col" style="padding-right:20px;" >
                <a scroll-to-top rounded href="#bcom">
                    <button type="button" class="btn btn-warning shadow-sm" style="font-size:24px">B.COM</button>
                </a>
            </div>
            <div class="col" align="left" style="padding-right:20px;" >
                <a href="#bba">
                    <button type="button" class="btn btn-primary shadow-sm" style="font-size:24px">BBA</button>
                </a>
            </div>
        </div>
    </div>
    <div align="center">
    <br>
    <br>
    <h2 align="center" class="text-success"><b>Post Graduate Courses</b></h2>
    <br>
    <!--Buttons-->
    <div class="row">
        <div class="col" align="right" style="padding-right:20px;"  >
            <a href="#mca">
                <button type="button" class="btn btn-danger shadow-sm" style="font-size:24px">MCA</button>
            </a>
        </div>
        <div class="col" style="padding-right:20px;" >
            <a href="#mcom"> 
                <button type="button" class="btn btn-warning shadow-sm" style="font-size:24px">M.COM</button>
            </a>
        </div>
        <div class="col" align="left" style="padding-right:20px;" >
           <a href="#mba"> 
            <button type="button" class="btn btn-primary shadow-sm" style="font-size:24px">MBA</button>
            </a>
        </div>
    </div>
    <!--Courses-->
    <br>
    <br>
    <div>
        <a id="bca">
            <h2 class="text-danger" align="center" ><b><u>BACHELOR OF COMPUTER APPLICATIONS</u>
            </b></h2>
        </a>
        <br>    
        <table class="table table-dark table-striped" align="center" style="width:80%">
            <thead>
                <tr align="center">
                    <th scope="col">Semesters</th>
                    <th scope="col">College Fees</th>
                    <th scope="col">University Fees</th>
                </tr>
            </thead>
            <tbody>
                <tr align="center">
                    <th scope="row" >1</th>
                    <td>23,500</td>
                    <td>1,250</td>
                </tr>
                <tr align="center">
                    <th scope="row">2</th>
                    <td>21,250</td>
                    <td>1,500</td>
                </tr>
                <tr align="center">
                    <th scope="row">3</th>
                    <td>26,700</td>
                    <td>750</td>
                </tr >
                <tr align="center">
                    <th scope="row">4</th>
                    <td>25,000</td>
                    <td>1,000</td>
                </tr>
                <tr align="center">
                    <th scope="row">5</th>
                    <td>23,000</td>
                    <td>1,550</td>
                </tr>
                <tr align="center">
                    <th scope="row">6</th>
                    <td>19,200</td>
                    <td>2,150</td>
                </tr>
            </tbody>
        </table>
    </div>
    <br>
    <br>
    <div>
        <a id="bcom"><h2 class="text-warning" align="center" ><b><u>BACHELOR OF COMMERCE</u></b></h2>
        </a>
        <br>    
        <table class="table table-dark table-striped" align="center" style="width:80%">
            <thead>
                <tr align="center">
                    <th scope="col">Semesters</th>
                    <th scope="col">College Fees</th>
                    <th scope="col">University Fees</th>
                </tr>
            </thead>
            <tbody>           
                <tr align="center">
                    <th scope="row" >1</th>
                    <td>23,500</td>
                    <td>1,250</td>
                </tr>
                <tr align="center">
                    <th scope="row">2</th>
                    <td>21,250</td>
                    <td>1,500</td>
                </tr>
                <tr align="center">
                    <th scope="row">3</th>
                    <td>26,700</td>
                    <td>750</td>
                </tr >
                <tr align="center">
                    <th scope="row">4</th>
                    <td>25,000</td>
                    <td>1,000</td>
                </tr >
                <tr align="center">
                    <th scope="row">5</th>
                    <td>23,000</td>
                    <td>1,550</td>
                </tr>
                <tr align="center">
                    <th scope="row">6</th>
                    <td>19,200</td>
                    <td>2,150</td>
                </tr>
            </tbody>
        </table>
    </div>
    <br>
    <br>
    <div>
        <a id="bba"><h2 class="text-primary" align="center" ><b><u>BACHELOR OF BUSINESS ADMINISTRATION </u></b></h2>
        </a>
        <br>    
        <table class="table table-dark table-striped" align="center" style="width:80%">
            <thead>
                <tr align="center">
                    <th scope="col">Semesters</th>
                    <th scope="col">College Fees</th>
                    <th scope="col">University Fees</th>
                </tr>
            </thead>
            <tbody>
                <tr align="center">
                    <th scope="row" >1</th>
                    <td>23,500</td>
                    <td>1,250</td>
                </tr>
                    <tr align="center">
                    <th scope="row">2</th>
                    <td>21,250</td>
                    <td>1,500</td>
                </tr>
                <tr align="center">
                    <th scope="row">3</th>
                    <td>26,700</td>
                    <td>750</td>
                </tr>
                <tr align="center">
                    <th scope="row">4</th>
                    <td>25,000</td>
                    <td>1,000</td>
                </tr>
                <tr align="center">
                    <th scope="row">5</th>
                    <td>23,000</td>
                    <td>1,550</td>
                </tr>
                <tr align="center">
                    <th scope="row">6</th>
                    <td>19,200</td>
                    <td>2,150</td>
                </tr>
            </tbody>
        </table>
    </div>
    <br>
    <br>
    <div>
        <a id="mca"><h2 class="text-danger" align="center" ><b><u>MASTERS OF COMPUTER APPLICATIONS </u></b></h2>
        </a>
        <br>    
        <table class="table table-dark table-striped" align="center" style="width:80%">
            <thead>
                <tr align="center">
                  <th scope="col">Semesters</th>
                  <th scope="col">College Fees</th>
                  <th scope="col">University Fees</th>
                </tr>
            </thead>
            <tbody>
                <tr align="center">
                  <th scope="row" >1</th>
                  <td>43,500</td>
                  <td>1,250</td>
                </tr>
                <tr align="center">
                    <th scope="row">2</th>
                    <td>41,250</td>
                    <td>1,500</td>
                </tr>
                <tr align="center">
                    <th scope="row">3</th>
                    <td>46,700</td>
                    <td>750</td>
                </tr >
                <tr align="center">
                    <th scope="row">4</th>
                    <td>45,000</td>
                    <td>1,000</td>
                </tr >
            </tbody>
        </table>
    </div>
    <br>
    <br>
    <div>
        <a id="mcom"><h2 class="text-warning" align="center" >
            <b><u>MASTERS OF COMMERCE</u></b></h2>
        </a>
        <br>    
        <table class="table table-dark table-striped" align="center" style="width:80%">
            <thead>
                <tr align="center">
                    <th scope="col">Semesters</th>
                    <th scope="col">College Fees</th>
                    <th scope="col">University Fees</th>
                </tr>
            </thead>
            <tbody>
                <tr align="center">
                    <th scope="row" >1</th>
                    <td>43,500</td>
                    <td>1,250</td>
                </tr>
                <tr align="center">
                    <th scope="row">2</th>
                    <td>41,250</td>
                    <td>1,500</td>
                </tr>
                <tr align="center">
                    <th scope="row">3</th>
                    <td>46,700</td>
                    <td>750</td>
                </tr >
                <tr align="center">
                    <th scope="row">4</th>
                    <td>45,000</td>
                    <td>1,000</td>
                </tr >
            </tbody>
        </table>
    </div>
    <br>
    <br>
    <div>
        <a id="mba"><h2 class="text-primary" align="center" >
            <b><u>MASTERS OF BUSINESS ADMINISTRATION </u></b></h2>
        </a>
        <br>    
        <table class="table table-dark table-striped" align="center" style="width:80%">
            <thead>
                <tr align="center">
                    <th scope="col">Semesters</th>
                    <th scope="col">College Fees</th>
                    <th scope="col">University Fees</th>
                </tr>
            </thead>
            <tbody>
                <tr align="center">
                    <th scope="row" >1</th>
                    <td>43,500</td>
                    <td>1,250</td>
                </tr>
                <tr align="center">
                    <th scope="row">2</th>
                    <td>41,250</td>
                    <td>1,500</td>
                </tr>
                <tr align="center">
                    <th scope="row">3</th>
                    <td>46,700</td>
                    <td>750</td>
                </tr >
                <tr align="center">
                    <th scope="row">4</th>
                    <td>45,000</td>
                    <td>1,000</td>
                </tr >
            </tbody>
        </table>
    </div>
    
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>
</body>
</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>