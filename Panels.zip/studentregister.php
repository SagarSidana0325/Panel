<?php include('error.php');?>
<?php include('head.php');?>  
<!doctype html>
<html lang="en">
<head>
    <title>StudentRegister</title>
</head>
<body style="background-color:mediumseagreen;">
    <br>
	<div class="container  sm  border border-1 border-dark shadow-lg rounded-3 " style="width:30%; background-color: white; height:470px">
    <br>
		<div align="center">
			<h4 align="center" class=" shadow-lg rounded-3 bg-primary text-light" style="width:75%; height: 42px;">Registeration Form
            </h4>	
		</div>
        <br>
		<form action="insertcode2.php" method="POST" >
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col">
                        <label for="formGroupExampleInput" class="form-label">First Name</label>
                        <input type="text" class="form-control" placeholder="First name" aria-label="First name" name="fname" required>
                    </div>
                    <div class="col ">
                        <label for="formGroupExampleInput" class="form-label">Last Name</label>
                        <input type="text" class="form-control" placeholder="Last name" name="lname" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="formGroupExampleInput" class="form-label">Enter Course</label>
                    <input type="text" name="course" class="form-control" placeholder="Enter Course" required>
                </div>
                <div class="mb-3">
					<label for="formGroupExampleInput" class="form-label">Phone Number</label>
                    <input type="number" name="contact" class="form-control" placeholder="Enter Phone Number" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" name="insertdata2" class="btn btn-primary">Register</button>
            </div>
        </form>
        <br>
        <div align="center">
            <p><b>Already Registered ? Login </b></p>
            <a href="studentlogin.php"><button type="submit" class="btn btn-dark">Log In</button></a>
		</div>
    </body>
</html> 