<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<body style="background-color: mediumseagreen;">
     <form action="login.php" method="post" class="shadow-lg  text-dark" style="width:30%">
     	<h2><b>ADMIN LOGIN</b></h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<label class="text-dark">Username</label>
     	<input  type="text" name="uname" placeholder="User Name" class="form-control" required><br>
     	<label class="text-dark">Password</label>
     	<input type="password" name="password" placeholder="Password" class="form-control" required><br>
     	<button type="submit" class="bg-primary">Login</button>
     </form>
</body>
</html>