<?php
session_start();
include("config.php");
if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>Students</title>

	<!-- CSS FILES  -->

	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/fixedheader/3.1.7/css/fixedHeader.bootstrap.min.css">
	 <link rel="stylesheet" href="css/theme.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.bootstrap.min.css">
	<link rel="stylesheet" href="datepicker/css/bootstrap-datepicker.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min">
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
		rel="stylesheet">
	<link href="css/sb-admin-2.min.css" rel="stylesheet">
	<link rel="stylesheet" href="extensions/sticky-header/bootstrap-table-sticky-header.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">

	<!-- JAVASCRIPT FILES  -->

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
    <script src="js/theme.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/fixedheader/3.1.7/js/dataTables.fixedHeader.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/dataTables.responsive.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.5/js/responsive.bootstrap.min.js"></script>
	<script src="datepicker/js/bootstrap-datepicker.min.js"></script>
	<script src="extensions/sticky-header/bootstrap-table-sticky-header.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script src="js/observers.js"></script>
    <script src="js/theme.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
	<script src="js/sb-admin-2.min.js"></script>

	<!--  SCRIPTING -->

    <script>
		$(document).ready(function(){
		  $("#theme").click(function(){
		    $("#mode").toggleClass("darkgrey");
		    $("#mode").toggleClass("text-light");
		    $("#ul").toggleClass("bg-dark");
		    $("#theme").toggleClass("text-light");
		    $("#active").toggleClass("bg-dark");
		    $("#add").toggleClass("bg-dark");
		    $("#update").toggleClass("bg-dark");
		    $("#delete").toggleClass("bg-dark");
		  });
		});
	</script>
 	<script type="text/javascript">
		$(document).ready(function(){
		  $(window).scroll(function(){
		    var scroll = $(window).scrollTop();
		      if (scroll > 300) {
		        $(".black").css("background" , "Mediumseagreen");
		      }

		      else{
		          $(".black").css("background" , "#333");   
		      }
		  })
		})
 	</script> 
 	<script type="text/javascript" class="init">
		$(document).ready(function() {
			// Setup - add a text input to each footer cell
			$('#search thead th').each( function () {
				var title = $(this).text();
				$(this).html( ''+title+' <br><input type="text" class="filter"  placeholder="Search" />' );
			} );
			// DataTable
			var table = $('#search').DataTable({
				responsive: true,
				initComplete: function () {
					// Apply the search
					this.api().columns().every( function () {
						var that = this;
						$( 'input', this.header() ).on( 'keyup change clear', function () {
							if ( that.search() !== this.value ) {
								that
									.search( this.value )
									.draw();
							}
						} );
					} );
				}
			});
		} );
	</script>
	<script>
	    $(document).ready(function () {
	        $('.editbtn').on('click', function () {
	            $('#editmodal').modal('show');
	            $tr = $(this).closest('tr');
	            var data = $tr.children("td").map(function () {
	                return $(this).text();
	            }).get();
	                console.log(data);
	                $('#fname').val(data[1]);
	                $('#lname').val(data[2]);
	                $('#course').val(data[3]);
	                $('#contact').val(data[4]);
	            });
	        $('#custForm').submit(function() {
	        	// ajax
		        $.ajax({
		            type:"POST",
		            url: "update.php",
		            data: $(this).serialize(), // get all form field value in 
		            dataType: 'json',
		            success: function(res){
		             window.location.reload();
		           }
		        });

	   		});
        });
	</script>
	<script>
        $(window).on("load",function(){ 
            $(".loader-container").fadeOut(2000);
        });
    </script>
    <script>
        $(document).ready(function () {
            $(document).on('click','.deletebtn',function (){
                value = $(this).data('attr');
                if (confirm('Are you sure want to delete the data?')){
                    $.ajax({
                        url: 'delete_record.php',
                        method: 'POST',
                        data: 'id='+value+'&name=test',
                        success: function(response) {
                            alert(response);
                            $('#user_info_'+value).remove();
                        },error: function (e){
                            alert(e.statusText);
                        }
                    })
                }    
            })
        });
    </script>
    <script>
    $(document).ready(function () {
        $('.editbtn').on('click', function () {
            $('#editmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();
                console.log(data);
                $('#id').val(data[0]);
                $('#fname').val(data[1]);
                $('#lname').val(data[2]);
                $('#course').val(data[3]);
                $('#contact').val(data[4]);
            });
        	$('#custForm').submit(function() {
        	// ajax
	        	$.ajax({
	            	type:"POST",
	            	url: "update.php",
	            	data: $(this).serialize(), // get all form field value in 
	            	dataType: 'json',
	            	success: function(res){
	            	 window.location.reload();
	           		}
	        	});
    		});
    	});
	</script>
	<script>  
	$(document).ready(function(){  
	    function fetch_data()  
	    {  
	        $.ajax({  
	            url:"select.php",  
	            method:"POST",  
	            success:function(data){  
					$('#live_data').html(data);  
	            }  
	        });  
	    }  
	    fetch_data();  
	    $(document).on('click', '#btn_add', function(){  
	        var fname = $('#fname').text();  
	        var lname = $('#lname').text(); 
	        var course = $('#course').text();
	        var contact = $('#contact').text(); 
	        if(fname == '')  
	        {  
	            alert("Enter First Name");  
	            return false;  
	        }  
	        if(lname == '')  
	        {  
	            alert("Enter Last Name");  
	            return false;  
	        } 
	         if(course == '')  
	        {  
	            alert("Enter Course");  
	            return false;  
	        }  
	         if(contact == '')  
	        {  
	            alert("Enter Contact");  
	            return false;  
	        }   
	        $.ajax({  
	            url:"insert.php",  
	            method:"POST",  
	            data:{fname:fname, lname:lname,course:course,contact:contact},  
	            dataType:"text",  
	            success:function(data)  
	            {  
	                alert(data);  
	                fetch_data();  
	            }  
	        })  
	    });  
	    
		function edit_data(id, text, column_name)  
	    {  
	        $.ajax({  
	            url:"edit.php",  
	            method:"POST",  
	            data:{id:id, text:text, column_name:column_name},  
	            dataType:"text",  
	            success:function(data){  
	                //alert(data);
					$('#result').html("<div class='alert alert-success'>"+data+"</div>");
	            }  
	        });  
	    }  
	    $(document).on('blur', '.fname', function(){  
	        var id = $(this).data("id1");  
	        var fname = $(this).text();  
	        edit_data(id, fname, "fname");  
	    });  
	    $(document).on('blur', '.lname', function(){  
	        var id = $(this).data("id2");  
	        var lname = $(this).text();  
	        edit_data(id,lname, "lname");  
	    });
	     $(document).on('blur', '.course', function(){  
	        var id = $(this).data("id3");  
	        var course = $(this).text();  
	        edit_data(id,course, "course");  
	    });  
	     $(document).on('blur', '.contact', function(){  
	        var id = $(this).data("id4");  
	        var contact = $(this).text();  
	        edit_data(id,contact, "contact");  
	    });    
	    $(document).on('click', '.btn_delete', function(){  
	        var id=$(this).data("id5");  
	        if(confirm("Are you sure you want to delete this?"))  
	        {  
	            $.ajax({  
	                url:"delete.php",  
	                method:"POST",  
	                data:{id:id},  
	                dataType:"text",  
	                success:function(data){  
	                    alert(data);  
	                    fetch_data();  
	                }  
	            });  
	        }  
	    });  
	});  
	</script>

	<!--  STYLING -->

 	<style >
     	.black{
		  	position:fixed;
		  	top:0;
		  	background:#333;
		  	color: white;
		  	width:100%;
		  	height:50px;
		}
	 	.darkgrey {
	  		background-color:#282828;
		}
		.bg-green{
			background-color: mediumseagreen;
		}
		.black ul{
		  	list-style-type:none;
		  	padding:0;
		}
		.black ul li{
 		 	display:inline-block;
	  		width:100px;
	  		color:red;
		}
		.blue{
	  		position:fixed;
	  		top:0;
	  		background:blue;
	  		width:100%;
	  		height:50px;
		}
		.loader-container{
		    width: 100%;
		    height: 100vh;
		    background-color: black;
		    position: fixed;
		    display: flex;
		    align-items: center;
		    justify-content: center;
		}
		.loader{
		    width: 50px;
		    height: 50px;
		    border: 5px solid;
		    color: #3498db;
		    border-radius: 50%;
		    border-top-color: transparent;
		    animation: loader 1.2s linear infinite;
		}
		@keyframes loader{
		    25%{
		        color: #2ecc71;
		    }
		    50%{
		        color: #f1c40f;
		    }
		    75%{
		        color: #e74c3c;
		    }
		    to{
		        transform: rotate(360deg);
		    }
		}
	</style>
 
</head>
<body id="page-top">
	<body id="page-top">
    <div class="loader-container">
        <div class="loader"></div>
    </div>
	<!-- Page Wrapper -->
<div id="mode" class="darkgrey text-light" >
	<!-- Sidebar -->
	<ul id="ul" class="navbar-nav  bg-green bg-dark sidebar sidebar-dark accordion fixed-top" id="accordionSidebar">
        <!-- Sidebar - Brand -->
        <a  class="sidebar-brand d-flex align-items-center text-light  justify-content-center" href="panel.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3 ">
                <h5>Welcome</h5>
            </div>
        </a>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">
        <!-- Nav Item - Dashboard -->
        <li class="nav-item active"> 
            <a class="nav-link " href="panel.php" >
                <i class="fas fa-fw fa-home" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Home</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Teachers.php">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span><font style="font-size: 18px;">Teachers</font></span>
            </a>
        </li>
        <li class="nav-item active"> 
            <a class="nav-link" href="Students.php" id="active"  style="background-color:mediumseagreen;">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Students</font>
                </span>
            </a>
        </li>
        <!-- Nav Item - Utilities Collapse Menu -->
        <li class="nav-item active">
            <a class="nav-link collapsed" href="Schedule.php" >
                <i class="fas fa-fw fa-calendar" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Schedule</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Courses.php">
                <i class="fas fa-fw fa-graduation-cap" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Courses</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <li class="nav-item active"> 
            <a class="nav-link" href="index.php">
                <i class="fas fa-fw fa-sign-out-alt" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Logout</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
    </ul>
	<!-- End of Sidebar -->
	<!-- Content Wrapper -->
	<div  class="d-flex   flex-column" style="margin-left: 220px;">
	<!-- Main Content -->
	<!-- Topbar -->
		 <nav class="navbar black fixed-top navbar-expand navbar-light topbar mb-4 static-top shadow" style="margin-left: 224px;"> 
                <ul>
                    <li><h3 align="left" class="text-light" style="width:1000px"><b>Admin Panel</b></h3></li>
                    <li style="margin-top:30px;"><h3 align="right" class="text-light" style="width:1000px"><font style="font-size:12px"><i id="theme" class="fas fa-sun fa-3x theme_icon "  ></i></font></h3>
                    </li>
                </ul>
                
            </nav>
		<br><br><br><br>

		<!-- ADD STUDENT -->

		<div class="modal fade" id="studentaddmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
			<div class="modal-dialog" role="document">
				<div class="modal-content bg-dark" id="add">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Add Student Data </h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<p id="msg"></p>
					<form action="insertcode" method="POST">
						<div class="modal-body">
							<div class="form-group">
								<label> First Name </label>
								<input type="text" name="fname" class="form-control" placeholder="Enter First Name">
							</div>
							<div class="form-group">
								<label> Last Name </label>
								<input type="text" name="lname" class="form-control" placeholder="Enter Last Name">
							</div>
							<div class="form-group">
								<label> Course </label>
								<input type="text" name="course" class="form-control" placeholder="Enter Course">
							</div>
							<div class="form-group">
								<label> Phone Number </label>
								<input type="number" name="contact" class="form-control" placeholder="Enter Phone Number">
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close
							</button>
							<button type="submit"  name="insertdata" id="insert" class="btn btn-primary">Save
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>

		<!--  TABLE START -->

		<div class="container well" >
				<button type="button" class="btn btn-info " data-toggle="modal" data-target="#studentaddmodal" >
					ADD STUDENT 
				</button>
			<div class="container">  
            	<br>  
				<div class="table-responsive">  
					<span id="result"></span>
					<div id="live_data"></div>                 
				</div>  
			</div>
		</div>

		<!--  TABLE END -->

		<!-- Scroll Up  -->

		<a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    
</body>


</html>
<?php 
}else{
	 header("Location: index.php");
	 exit();
}
 ?>
  