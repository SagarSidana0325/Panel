<?php

$x=10;

if($x%2==0)

{

	echo"The Number Is Even";
}


?>