<?php

$x=13;

if($x<10)

{

	echo"The Number Is smaller than 10";
}

elseif($x==10){

	print"The Number Is 10";
}

else{

	echo"The Number IS greater than 10";
}

?>