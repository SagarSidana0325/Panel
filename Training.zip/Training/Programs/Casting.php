<?php


$x=50.6;

$s=(int)$x;

	echo $s;

echo"<br>";

$y=70;
	$J=(float)$y;
	echo $J;	

?>