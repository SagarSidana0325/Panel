<?php


$x=50;
$y=30;
	
function ADD(){
	$GLOBALS['z']=$GLOBALS['x']+$GLOBALS['y'];

}
ADD();
echo $z;
?>