<?php

$a="Sagar Sidana Shilpa Sidana Kajal Sidana Sakshi Sidana";
$b="/id/i";

echo preg_replace($b,"idh",$a);


?>

