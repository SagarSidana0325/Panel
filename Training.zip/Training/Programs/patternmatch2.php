<?php

$a="Sagar Sidana Shilpa Sidana Kajal Sidana Sakshi Sidana";
$b="/id/i";

echo preg_match_all($b, $a,);


?>

