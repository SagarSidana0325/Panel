<?php

echo "<br>Pi : ";
	echo (pi());


echo "<br>Min : ";
	echo (min(3,16,8,25));

echo "<br>Max : ";
	echo (max(3,16,8,25));

echo "<br>Absolute : ";
	echo (abs(-25));		
		
echo "<br>Square Root : ";
	echo (sqrt(4225));	

echo "<br>Round Off : ";
	echo (round(7.64));

echo "<br>Random No.: ";
	echo (rand());

echo "<br>Random Number Between a Range : ";
	echo (rand(10,20));



?>