<?php

function Sagar($fname,$year){

echo"$fname was born in $year <br>";

}
Sagar("Sagar",1999);
Sagar("Jasmeen",1999);
Sagar("Shikha",1998);
Sagar("Deepika",1999);

?>