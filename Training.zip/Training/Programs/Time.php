<?php

date_default_timezone_set("America/New_York");
echo "The Time Is : " .date("h:i:sa");
?>

