<?php

$x=10;

do
{
echo"Number Is : $x <br>";
$x++;
}

while($x<=20)


?>