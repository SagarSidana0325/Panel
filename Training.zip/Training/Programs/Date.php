<?php

echo "Today is ".date("m/Y/d")."!";
echo "<br>";
echo date("m.Y.d");
echo "<br>";
echo date("m-Y-d");
echo "<br>";
echo date("l");
?>

