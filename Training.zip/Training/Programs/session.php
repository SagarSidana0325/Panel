<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Set session variables
$_SESSION["FirstName"] = "Jasmeen";
$_SESSION["LastName"] = "Rekhi";
echo "Session variables are set.";
?>


</body>
</html>