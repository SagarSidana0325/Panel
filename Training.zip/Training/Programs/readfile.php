<?php
$sagar=fopen('Sagar.txt','r') or die("Cant Open");

while(!feof($sagar)){
	echo fgets($sagar),"<br>";
}

?>