<?php
$file=fopen('Sagar.txt','a') or die("Cant Open");
$txt="\n Shikha Solanki";
fwrite($file, $txt);
fclose($file);
?>