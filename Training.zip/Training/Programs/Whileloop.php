<?php

$x=10;


while($x<25)

{
echo"Number Is : $x <br>";
$x++;
}
?>