<?php 
$errors = [];
  if(isset($_POST) && $_POST){
      if(isset($_POST['fname']) && empty($_POST['fname'])){
        $errors['fname'] = 'First Name Cannot Be Blank !';
      }
      if(isset($_POST['lname']) && empty($_POST['lname'])){
        $errors['lname'] = 'Last Name Cannot Be Blank !';
      }
  
      if(isset($_POST['email']) && empty($_POST['email'])){
        $errors['email'] = 'Please Enter Your Email !';
      }
      if(isset($_POST['password']) && empty($_POST['password'])){
        $errors['password'] = 'Enter a Strong password !';
      }
      if(isset($_POST['city']) && empty($_POST['city'])){
        $errors['city'] = 'Enter Your City !';
      }

  }
 
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>form</title>
  </head>
  <body>
<br>
  		<div class="container  sm  border border-1 border-dark shadow-lg rounded-3 "   style= " background: linear-gradient(to right, MediumSeaGreen  , white) ; width:50%;">
<br>
			<div align="center">
 				<h3 align=" center" class=" shadow-lg rounded-pill" style="width:40%; height: 42px; background-color: black; color:white;">FORM</h3>	
			</div>
			<div align="center">
				<h2 class="border border-dark border-2 bg-light" style="width:60%; "> ENTER YOUR DETAILS</h2>
			</div>
<br>
			<form class="needs-validation" novalidate autocomplete="off"  method="post" >
				<div class="row">
					<div class="col" align="center">	
						<div class="row">
  							<div class="col">
    							<label for="validationCustom01" class="form-label "><b><h5 style="font-family: Lucida Calligraphy;"><b>First Name</b></h5>
    							</label>
    							<input type="text" name="fname" value="<?php echo $_POST['fname'] ?? ''; ?>"  class="form-control border shadow-sm text-dark border border-1 border-dark" id="validationCustom01" style="width:50%;height:40px">
    								<?php if(isset($errors['fname'])){ ?>
              							<div class="text-danger"><?php echo $errors['fname'] ?></div>
          								<?php } 
          							?>
  							</div>
						</div>
<br>
						<div class="row">
  							<div class="col">
    							<label for="inputPassword4" class="form-label"><h5 style="font-family: Lucida Calligraphy;"><b>Last Name</b></h5>
    							</label>
    							<input type="text" name="lname" value="<?php echo $_POST['lname'] ?? ''; ?>" class="form-control border shadow-sm text-dark border border-1 border-dark" id="inputPassword4" style="width: 50%;height:40px">
    								<?php if(isset($errors['lname'])){ ?>
              							<div class="text-danger"><?php echo $errors['lname'] ?></div>
          								<?php } 
          							?>

  							</div>
						</div>
<br>
						<div class="row">
						  	<div class="col" >
						    	<label for="inputEmail4" class="form-label "><h5 style="font-family: Lucida Calligraphy;"><b>Email ID :</b></h5>
						    	</label>
						    	<input type="text" name="email" value="<?php echo $_POST['email'] ?? ''; ?>" class="form-control border shadow-sm text-dark border border-1 border-dark" id="inputEmail4" style="width:50%;height:40px; margin-left: 10px;">
						    		<?php if(isset($errors['email'])){ ?>
              							<div class="text-danger"><?php echo $errors['email'] ?></div>
          								<?php } 
          							?>
						  	</div>
						</div>  
<br>
						<div class="row">
						  	<div class="col">
						    	<label for="inputPassword4" class="form-label"><h5 style="font-family: Lucida Calligraphy;"><b>Password</b></h5>
						    	</label>
						    	<input type="password" name="password" 	 value="<?php echo $_POST['password'] ?? ''; ?>" class="form-control border shadow-sm text-dark border border-1 border-dark" id="inputPassword4" style="width:50%;margin-left: 10px;height:40px">
						    		<?php if(isset($errors['password'])){ ?>
              							<div class="text-danger"><?php echo $errors['password'] ?></div>
          								<?php } 
          							?>
						  	</div>
						</div>
<br>
						<div class="row">
  							<div class="col">
    							<label for="inputPassword4" class="form-label"><h5 style="font-family: Lucida Calligraphy;"><b>Your City</b></h5>
    							</label>
    							<input type="text" name="city" value="<?php echo $_POST['city'] ?? ''; ?>" class="form-control border  text-dark border border-1 border-dark" id="inputPassword4" style="width:50%;margin-left: 11px;height:40px">
    								<?php if(isset($errors['city'])){ ?>
              							<div class="text-danger"><?php echo $errors['city'] ?></div>
          								<?php } 
          							?>
  							</div>
						</div>
<br>
						<div class="row" >
  							<div class="col" align="left">
    							<button type="submit" class="btn btn-primary"align="center" style="width:15%" >Submit</button>
  							</div>
						</div>  
					</div>
				</div>
<br>
			</form>
		</div>

	</body>
</html>