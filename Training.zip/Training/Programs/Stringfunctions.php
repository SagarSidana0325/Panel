<?php


$s="Hello ! I Am Sagar Sidana";

echo "String Functions <br>";

	echo "String Length :";
	echo strlen($s);

	echo "<br>String Reverse :";
	echo strrev($s);	

	echo "<br>String Position :";
	echo strpos($s,"Sagar");

	echo "<br>String Replace :";
	echo str_replace("Sagar"," Shilpa",$s);




?>