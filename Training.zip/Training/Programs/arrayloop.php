<?php

$x=0;
$sagar = array("Sagar","Shikha","Jasmeen","Deepika");


while($x<=3)
{
echo"$sagar[$x]<br>";
$x++;
}
?>