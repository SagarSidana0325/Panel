<?php
$str = "Sagar Sidana";
$pattern = "/Sid/i";
echo preg_match($pattern, $str); 
?>
