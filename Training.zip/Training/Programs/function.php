<?php

function Sagar(){

echo"Hello Everyone";

}


Sagar();
?>