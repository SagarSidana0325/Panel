<?php

$x=10;
$y=20;

//Operators

echo"Sum <br>";
	echo $x+$y;

	




?>