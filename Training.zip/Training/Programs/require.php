<?php 
require 'sample.php';
echo "My Name is : $name"."<br>";
echo "My Favourite Color is : $fav_color"."<br>";
?>
