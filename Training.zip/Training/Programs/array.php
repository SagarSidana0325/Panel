<?php

$sagar = array("Sagar","Shikha","Jasmeen","Deepika");

echo"$sagar[0]";
?>