<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Echo session variables that were set on previous page
echo "First Name : " . $_SESSION["FirstName"] . ".<br>";
echo "Last Name : " . $_SESSION["LastName"] . ".<br>";
echo "Contact : ".$_SESSION["Phone"].".<br>";

print_r($_SESSION);
?>

</body>
</html>