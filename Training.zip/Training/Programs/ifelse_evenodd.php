<?php

$x=13;

if($x%2==0)

{

	echo"The Number Is Even";
}

else{

	print"The Number Is Odd";
}

?>