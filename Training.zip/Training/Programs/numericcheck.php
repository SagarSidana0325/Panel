<?php


$x=50.6;
$y="Sagar";
	


var_dump(is_numeric($x));	

var_dump(is_numeric($y));


?>