<?php

function Sagar($fname){

echo"$fname Sidana <br>";

}
Sagar("Sagar");
Sagar("Sakshi");
Sagar("Shilpa");
Sagar("Kajal");

?>