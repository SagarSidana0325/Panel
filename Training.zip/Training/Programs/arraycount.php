<?php

$x=0;
$sagar = array("Sagar","Shikha","Jasmeen","Deepika");


	echo count($sagar);


?>