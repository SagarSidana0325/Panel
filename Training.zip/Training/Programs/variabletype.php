<?php


$x=50.6;

	var_dump(is_int($x));

$y=3;
	
	var_dump(is_int($y));



?>