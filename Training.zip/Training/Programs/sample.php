<?php

$name="Sagar";
$fav_color="Black";

?>
