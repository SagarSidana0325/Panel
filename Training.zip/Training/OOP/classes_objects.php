<?php
class India{
	public $name;
	function firstname($fname)
	{
		$this->name=$fname;
	}
}
$abc = new India();
$abc->firstname("Sagar");
echo $abc->name;
?>