<?php
class india{
	public $name;
		function __construct($fname){
 			$this->name=$fname;
		}
		function getname(){
			return $this->name;
		}
}
$abc = new india("Virat");
echo $abc->getname();	
?>