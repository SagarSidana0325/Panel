<?php
class student{
	public $fname;
	public $lname;
	public function __construct($fname,$lname)
		{
			$this->fname=$fname;
			$this->lname=$lname;
		}
	public function intro()
		{
			echo "<br>";
			echo "My Name is {$this->fname} {$this->lname} .";
		}
}
class hello extends student{
	public function msg()
		{
			echo "Hello !"; 
		}
}
$abc= new hello("Sagar","Sidana");
$abc->msg();
$abc->intro();
?>