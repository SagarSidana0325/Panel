<?php
class india{
public $fname;
public $lname;
	function __construct($fname,$lname)
		{
			$this->fname=$fname;
			$this->lname=$lname;
		}
	function __destruct()
		{
			echo "First Name is {$this->fname}";
			echo "<br>";
			echo "Last Name is {$this->lname}";
		}
}

$sagar = new india("Sagar","Sidana");	
?>