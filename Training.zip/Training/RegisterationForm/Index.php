<?php include('error.php');?>
<?php include('head.php');?>  
<!doctype html>
<html lang="en">

  <body bgcolor="blue">
<br>
  		<div class="container  sm  border border-1 border-dark shadow-lg rounded-3 "   style="width:40%; background-color: white; height:600px">
<br>
				<div align="center">
 				<h3 align="center" class=" shadow-lg rounded-pill" style="width:65%; height: 42px; background-color: black; color:white;">Registeration Form</h3>	
				</div>
			
<br>
			<form class="needs-validation"  novalidate autocomplete="off"  method="post" action="connect.php">
				<div class="row">
					<div class="col" align="center">	
						<div class="row">
  							<div class="col">
    							<input type="text" name="username" placeholder="Enter Username"   class="form-control border shadow-sm text-dark border border-1 border-dark" required style="width:70%;height:40px">
    								
  							</div>
						</div>
<br>
						<div class="row">
  							<div class="col">    							
    							<input type="password" name="password" placeholder="Enter Password" required class="form-control border shadow-sm text-dark border border-1 border-dark" id="inputPassword4" style="width: 70%;height:40px">
    								

  							</div>
						</div>
<br>
<div class="row">
  							<div class="col" style="padding-left: 100px;">
    							<div class="form-check" align="left">
  									<input class="form-check-input" type="radio" name="gender" value="m" required id="flexRadioDefault1" checked> 
  									<label class="form-check-label" for="flexRadioDefault1" align="">
    								Male
  									</label>
								</div>
								<div class="form-check" align="left">
  									<input class="form-check-input" type="radio" name="gender" required value="f" >
  									<label class="form-check-label" for="flexRadioDefault2">
    								Female	
  									</label>
								</div>
  							</div>
						</div>
<br>				
						<div class="row">
						  	<div class="col" >
						    	<input type="text" name="email" placeholder="Enter Your Email" required  class="form-control border shadow-sm text-dark border border-1 border-dark" id="inputEmail4" style="width:70%;height:40px; ">
						    		
						  	</div>
						</div>  
<br>
						<div class="row">
						  	<div class="col">						    	
						    	<input type="phone" name="phone" placeholder="Phone Number"	  class="form-control border shadow-sm text-dark border border-1 border-dark" id="inputPassword4" style="width:70%;height:40px">
						    		
						  	</div>
						</div>
<br>
							
							
							<div class="row" >
	  							<div class="col" align="" >
	    							<button type="submit" class="btn btn-primary" align="center" style="width:70%;">Submit</button>
	  							</div>
							</div>  						
				</div>
<br>
			</form>
		</div>
	</body>
</html>