<html>
    <body>
        <h1 align="center">Details</h1>
            <table border="1" width="1000px" align="center">
                <tr>
                    <td align="center" height="40px"><h3>First Name</h3></td>
                    <td align="center" height="40px"><h3>Last Name </h3></td>
                    <td align="center" height="40px"><h3>Email</h3></td>
                    <td align="center" height="40px"><h3>City</h3></td>
                    <td align="center" height="40px"><h3>Picture</h3></td>
                </tr>
                <tr>
                    <td align="center" height="30px"><?php echo $_POST["fname"]; ?></td>
                    <td align="center" height="30px"><?php echo $_POST["lname"]; ?></td>
                    <td align="center" height="30px"><?php echo $_POST["email"]; ?></td>
                    <td align="center" height="30px"><?php echo $_POST["city"]; ?></td>
                    <td align="center" height="30px"><img src="<?php echo $_POST["pic"]; ?>" height="100px" width="100"></td>
                </tr>
            </table>    
    </body>
</html>
 