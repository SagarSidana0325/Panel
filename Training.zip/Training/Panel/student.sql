-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 19, 2022 at 04:10 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `course` varchar(30) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `createdDate` datetime DEFAULT NULL,
  `modifiedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `fname`, `lname`, `course`, `contact`, `createdDate`, `modifiedDate`) VALUES
(57, 'Sagar', 'Sidana', 'MCA', 9888250036, '2022-08-16 13:22:53', '2022-08-17 14:55:53'),
(42, 'Sparsh', 'Grover', 'MBA', 8978745987, '2022-08-05 09:38:06', '2022-08-17 15:00:56'),
(87, 'Sagar', 'Plaha', 'BBA', 9877845998, '2022-08-18 13:56:22', NULL),
(86, 'Jasmeen', 'Rekhi', 'MCA', 8427754079, '2022-08-18 13:55:29', NULL),
(45, 'Anish', 'Rajput', 'BCA', 9545987125, '2022-08-05 09:40:11', '2022-08-17 12:11:55'),
(47, 'Pankaj', 'Prasher', 'MCA', 8347959874, '2022-08-05 09:40:25', '2022-08-05 12:15:44'),
(48, 'Sanyam', 'Verma', 'BCA', 8569310257, '2022-08-05 09:40:44', '2022-08-17 10:38:42'),
(60, 'Shikha', 'Solanki', 'MCA', 6239551726, '2022-08-16 15:52:02', NULL),
(84, 'Deepika', 'Thakur', 'MBA', 9877845998, '2022-08-18 11:38:00', NULL),
(82, 'Devika', 'Sharma', 'BBA', 9877845668, '2022-08-18 10:11:48', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
