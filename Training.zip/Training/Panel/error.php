<?php 
$errors = [];
  if(isset($_POST) && $_POST){
      if(isset($_POST['email']) && empty($_POST['email'])){
        $errors['email'] = 'Please Enter Your Email !';
      }
      if(isset($_POST['password']) && empty($_POST['password'])){
        $errors['password'] = 'Enter Password !';
      }
  }
?>