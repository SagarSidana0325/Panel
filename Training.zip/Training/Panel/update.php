<?php

if(count($_POST)>0)
{    
     include 'mydbCon.php';
     
     $fname = $_POST['fname'];
     $lname = $_POST['lname'];
     $course = $_POST['course'];
     $contact = $_POST['contact'];
     $id = $_POST['id'];

     $query = "UPDATE student SET fname='$fname', lname='$lname', course='$course', contact=' $contact',modifiedDate=now() WHERE id='$id'  "; // update form data from the database
     
     echo 'Data Updated';

    $res = mysqli_query($dbCon, $query);

    if($res) {

     echo json_encode($res);

    } else {

     echo "Error: " . $sql . "" . mysqli_error($dbCon);

    }

}

?>