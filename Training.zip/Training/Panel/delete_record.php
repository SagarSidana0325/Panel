<?php
require_once 'connection.php';
$id = $_POST['id'] ?? 0;
$db = new Db();
$query = 'delete from student where id='.$id;
$records = $db->query($query);
echo 'Your record has been deleted successfully';
exit;
?>