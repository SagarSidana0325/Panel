<?php
$connection = mysqli_connect("localhost","root","",);
$db = mysqli_select_db($connection, 'admin');

    /* Inserting Data*/
if(isset($_POST['insertdata']))
    {
        $fname   = $_POST['fname'];
        $lname   = $_POST['lname'];
        $course  = $_POST['course'];
        $contact = $_POST['contact'];
        $query   = "INSERT INTO student (`fname`,`lname`,`course`,`contact`,`createdDate`) VALUES ('$fname','$lname','$course','$contact',now())";

        $query_run = mysqli_query($connection, $query);

        /* Insert Message */
        if($query_run)
            {
                echo '<script> alert("Data Saved"); </script>';
                header('Location:Students.php');
            }
        else
            {
                echo '<script> alert("Data Not Saved"); </script>';
            }
    }
?>