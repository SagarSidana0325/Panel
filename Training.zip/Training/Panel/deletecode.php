<?php
$connection = mysqli_connect("localhost","root","");
$datab = mysqli_select_db($connection, 'admin');

$id = $_POST['id'] ?? 0;
$db = new Db();
$query = 'delete from student where id='.$id;
$records = $db->query($query);
echo 'Your record has been deleted successfully';
exit;
        
?>