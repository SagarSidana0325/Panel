<?php 
session_start();
if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Student</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="lightbox.min.css">
    <script type="text/javascript" src="lightbox-plus-jquery.min.js">
    </script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">
<div id="wrapper"  >
    <!-- Sidebar -->
    <ul class="navbar-nav bg-danger sidebar sidebar-dark accordion fixed-top" id="accordionSidebar" >
        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="studentpanel.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3">
                <h5 >Welcome</h5>
            </div>
        </a>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">
        <!-- Nav Item - Dashboard -->
        <li class="nav-item active"> 
            <a class="nav-link" href="studentpanel.php">
                <i class="fas fa-fw fa-tachometer-alt" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Home</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        <div class="sidebar-heading">
            Interface
        </div>
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="#profile">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Profile</font>
                </span>
            </a>
        </li>
        <li class="nav-item active"> 
            <a class="nav-link" href="#dmc">
                <i class="fas fa-fw fa-file" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">DMCs</font>
                </span>
            </a>
        </li>
        <!-- Nav Item - Utilities Collapse Menu -->
        <li class="nav-item active">
            <a class="nav-link collapsed" href="#Schedule" >
                <i class="fas fa-fw fa-calendar" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Schedule</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        
        <!-- Divider -->
        <hr class="sidebar-divider">
        <li class="nav-item active"> 
            <a class="nav-link" href="index.php">
                <i class="fas fa-fw fa-sign-out-alt" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Logout</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">
        </ul>
    <!-- End of Sidebar -->
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="margin-left: 220px;">
        <!-- Main Content -->
        <div id="content" >
            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow" >
                <h2><b><font style="color: black;">Student Panel</font></b></h2>
            </nav>
            <!-- End of Topbar -->
            <div class="container-fluid">
            <!-- Page Heading -->
                <div class="align-items-center" align="center" >
                    <h1><font style="font-size:72px;color: black;"><b>ABOUT GNIMT</b></font></h1>
                    <img src="img/campus.jpg" class="img-fluid shadow-sm" style="width:80%;border: 2px solid black;">
                    <br><br><br>
                    <p>GNIMT, has emerged as one of the leading institutes in imparting quality education ever since its inception in 1997. We, at GNIMT, believe in providing a stimulating environment for developing impressionable young minds. Our relentless approach of excellence has been well recognized.Our motto reiterates our guiding philosophy ASPIRE, PERSEVERE, ACHIEVE. In a short span of time, GNIMT has earned the reputation of being an Institute of toppers & winners in the field of academics, sports and other extra-curricular activities. The Institute is an ISO: 9001:2000 certified organization and our quality policy emphasizes on the goals of providing excellent human resource to the society. The Institute is fully equipped with audio- visual aids and has air conditioned class rooms, labs, library & all the ultra modern facilities.</p>
                </div>
            </div>
            <div class="container-fluid"  >
            <!-- Page Heading -->
            <hr>
                <div class="align-items-center" align="center" id="profile">
                    <h1>
                    <font style="font-size:72px;color:black;"><b><u>My Profile</u></b></font>
                    </h1>
                    <img src="img/me.jpg"  class="img-fluid" style="width:25%">
                </div>
                <br>
                <table class="table caption-top table-success text-dark" align="center" style="width:60%;font-size: 20px;" >
                    <thead align="center">
                        <tr>
                            <th scope="col">First Name</th>
                            <th scope="col">Sagar</th>
                        </tr>
                    </thead>
                    <thead align="center">
                        <tr>
                            <th scope="col">Last Name</th>
                            <th scope="col">Sidana</th>
                        </tr>
                    </thead>
                    <thead align="center">
                        <tr>
                            <th scope="col">Email ID</th>
                            <th scope="col">ssidana238@gmail.com</th>
                        </tr>
                    </thead>
                    <thead align="center">
                        <tr>
                            <th scope="col">Course</th>
                            <th scope="col">MCA</th>
                        </tr>
                    </thead>
                    <thead align="center">
                        <tr>
                            <th scope="col">Contact Number</th>
                            <th scope="col">9888250036</th>
                        </tr>
                    </thead>
                </table>
            </div>
            <hr>
            <div class="align-items-center" align="center" id="dmc">
                <h1>
                <font style="font-size:72px;color:black;"><b><u>DMC</u></b></font>
                </h1>
            </div>
            <div class="row">
                <div class="gallery col" align="center">
                    <a href="img/dmc1.png" class="wow zoomin" data-lightbox="mygallery">
                        <img src="img/dmc1.png" class="shadow-sm" style="width:80%;border: 2px solid black;">
                    </a>
                </div>
                <div class="gallery col" align="center">
                    <a href="img/dmc2.png" data-lightbox="mygallery">
                        <img src="img/dmc2.png" class="shadow-sm" style="width:80%;border: 2px solid black;">
                    </a>
                </div>
                <div class="gallery col" align="center">
                    <a href="img/dmc3.png" data-lightbox="mygallery">
                        <img src="img/dmc3.png" class="shadow-sm" style="width:80%;border: 2px solid black;">
                    </a>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="gallery col" align="center">
                    <a href="img/dmc4.png" data-lightbox="mygallery">
                        <img src="img/dmc4.png" class="shadow-sm" style="width:80%;border: 2px solid black;">
                    </a>
                </div>
                <div class="gallery col" align="center">
                    <a href="img/dmc5.png" data-lightbox="mygallery">
                        <img src="img/dmc5.png" class="shadow-sm" style="width:80%;border: 2px solid black;">
                    </a>
                </div>
                <div class="gallery col" align="center">
                    <a href="img/dmc6.png"  data-lightbox="mygallery">
                        <img src="img/dmc6.png" class="shadow-sm" style="width:80%;border: 2px solid black;">
                    </a>
                </div>
            </div>
            <br>
            <hr>
            <div class="container-fluid">
            <!-- Page Heading -->
                <div class="align-items-center" align="center" >
                    <h1><font style="font-size:72px;color: black;"><b><u>Schedule</u></b></font></h1>
                </div>
                <table class="table caption-top table-dark table-striped" align="center" style="width:90%;font-size: 20px;" id="Schedule">
                    <thead align="left">
                        <tr>
                            <th scope="col">Lecture</th>
                            <th scope="col">Subject</th>
                            <th scope="col">Time</th>
                        </tr>
                    </thead>
                    <thead align="left">
                        <tr>
                            <th scope="col">I</th>
                            <th scope="col">Web Technologies</th>
                            <th scope="col">9:15-10:00</th>
                        </tr>
                    </thead>
                    <thead align="left">
                        <tr>
                            <th scope="col">II</th>
                            <th scope="col">Advanced Java</th>
                            <th scope="col">10:00-10:45</th>
                        </tr>
                    </thead>
                    <thead align="left">
                        <tr>
                            <th scope="col">III</th>
                            <th scope="col">Info. Security</th>
                            <th scope="col">10:45-11:30</th>
                        </tr>
                    </thead>
                    <thead align="left">
                        <tr>
                            <th scope="col">IV</th>
                            <th scope="col">DAA</th>
                            <th scope="col">11:30-12:15</th>
                        </tr>
                    </thead>
                    <thead align="left">
                        <tr>
                            <th scope="col">V</th>
                            <th scope="col">Linux Administration</th>
                            <th scope="col">12:15-1:00</th>
                        </tr>
                    </thead>
                    <thead align="left">
                        <tr>
                            <td scope="col" align="center"  colspan="3"><b>Break</b></td>
                            
                        </tr>
                    </thead>
                    <thead align="left">
                        <tr>
                            <th scope="col">VI</th>
                            <th scope="col">Web Technologies Lab</th>
                            <th scope="col">1:30-2:15</th>
                        </tr>
                    </thead>
                    <thead align="left">
                        <tr>
                            <th scope="col">VII</th>
                            <th scope="col">Advanced Java Lab</th>
                            <th scope="col">2:15-3:00</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>
<!-- Bootstrap core JavaScript-->


<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>
<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>
<!-- Page level custom scripts -->
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>
</body>
</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>