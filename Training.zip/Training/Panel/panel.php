
<?php 
session_start();
if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {
 ?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home</title>

    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="js/observers.js"></script>
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
     <link rel="stylesheet" href="css/theme.css">
     <script>
$(document).ready(function(){
  $("#theme").click(function(){
    $("#mode").toggleClass("darkgrey");
    $("#ul").toggleClass("bg-dark");
    $("#active").toggleClass("bg-dark");
     $("#theme").toggleClass("text-light");
     $("#h1").toggleClass("text-light");
  });
});
</script>

    <!-- My JS -->
    <script src="js/theme.js"></script>
 <style type="text/css">

  .darkgrey {   
  background-color:#282828;
}

.bg-green{
background-color: mediumseagreen;
}


     .black{
  position:fixed;
  top:0;
  background:#333;
  color: white;
  width:100%;
  height:50px;
  
}
.black ul{
  list-style-type:none;
  padding:0;
}

.black ul li{
  display:inline-block;
  width:100px;
  color:red;
}





 </style>
 <script type="text/javascript">
     
$(document).ready(function(){
  $(window).scroll(function(){
    var scroll = $(window).scrollTop();
      if (scroll > 150) {
        $(".black").css("background" , "Mediumseagreen");
      }

      else{
          $(".black").css("background" , "#333");   
      }
  })
})
 </script> 


</head>
<body id="page-top" >
   
<div id="wrapper"  >
    <!-- Sidebar -->
    <ul id="ul" class="navbar-nav  bg-green bg-dark sidebar sidebar-dark accordion fixed-top" id="accordionSidebar">
        <!-- Sidebar - Brand -->
        <a  class="sidebar-brand d-flex align-items-center text-light  justify-content-center" href="panel.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3 ">
                <h5>Welcome</h5>
            </div>
        </a>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">
        <!-- Nav Item - Dashboard -->
        <li class="nav-item active"> 
            <a id="active" class="nav-link " href="panel.php" style="background-color:mediumseagreen;">
                <i class="fas fa-fw fa-home" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Home</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Teachers.php">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span><font style="font-size: 18px;">Teachers</font></span>
            </a>
        </li>
        <li class="nav-item active"> 
            <a class="nav-link" href="Students.php">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Students</font>
                </span>
            </a>
        </li>
        <!-- Nav Item - Utilities Collapse Menu -->
        <li class="nav-item active">
            <a class="nav-link collapsed" href="Schedule.php" >
                <i class="fas fa-fw fa-calendar" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Schedule</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Courses.php">
                <i class="fas fa-fw fa-graduation-cap" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Courses</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <li class="nav-item active"> 
            <a class="nav-link" href="index.php">
                <i class="fas fa-fw fa-sign-out-alt" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Logout</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
    </ul>
    <!-- End of Sidebar -->
    <!-- Content Wrapper -->




    <!--  MAIN -->
    <div id="content-wrapper"  class="d-flex flex-column grey opacity-100" style="margin-left: 220px;">
        <div id="content ">
            <nav id="#nav" class="navbar black bg-green fixed-top navbar-expand navbar-light topbar mb-4 static-top shadow" style="margin-left: 224px;"> 
                <ul>
                    <li><h3 align="Center" class="text-light" style="width:1000px"><b>ADMIN PANEL</b></h3></li>
                    <li style="margin-top:30px;"><h3 align="right" class="text-light" style="width:1000px"><font style="font-size:12px"><i id="theme" class="fas fa-sun fa-3x theme_icon "  ></i></font></h3>
                    </li>
                </ul>
                
            </nav>
        </div>
            <div class="container-fluid darkgrey " id="mode" >
                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-dark">Dashboard</h1>
                </div>
                <!-- Content Row -->
                <div class="row" style="height: 150px;">
                    <!-- Stats -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div id="card" class="card border-left-info shadow bg-dark h-100 py-2 " style="background-color: #666666;">
                            <div class="card-body ">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            <font style="font-size:15px">Total Students</font>
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-info">2500
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar fa-2x text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Stats2 -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div id="card1" class="card border-left-success shadow bg-dark h-100 py-2 " style="background-color: #666666;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1 "><font style="font-size:15px">Avg. % Of Students</font>
                                        </div>
                                        <div class="row no-gutters align-items-center">
                                            <div class="col-auto">
                                                <div class="h5 mb-0 mr-3 font-weight-bold text-success">71%</div>
                                            </div>
                                            <div class="col">
                                                <div class="progress progress-sm mr-2">
                                                    <div class="progress-bar bg-success" role="progressbar" style="width: 71%" aria-valuenow="71" aria-valuemin="0"
                                                            aria-valuemax="100">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-award fa-2x text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Stats3 -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div id="card2" class="card border-left-warning shadow bg-dark h-100 py-2 " style="background-color: #666666;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            <font style="font-size:15px">Students Present Today</font>
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-warning">2340
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user fa-2x text-warning"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Content Row -->
                <div class="row ">
                    <!-- College Pic -->
                    <div class="col-xl-8 col-lg-7">
                        <img src="img/gnimt.jpg" class="img-fluid border" alt="...">  
                    </div>
                    <!-- Pie Chart -->
                    <div class="col-xl-4 col-lg-5" >
                        <div class="card shadow mb-4 text-light" >
                            <!-- Card Header - Dropdown -->
                            <div id="card3" class="card-header bg-dark py-3 d-flex flex-row align-items-center justify-content-between "style="background-color: #666666;" >
                                <h6 class="m-0 font-weight-bold text-primary">Marks Distribution Subject Wise  </h6>
                            </div>
                            <!-- Card Body -->
                            <div  id="card4" class="card-body bg-dark" style="background-color: #666666;">
                                <div class="chart-pie pt-4 pb-2">
                                    <canvas id="myPieChart"></canvas>
                                </div>
                                <div class="mt-4 text-center small">
                                    <span class="mr-2">
                                        <i class="fas fa-circle text-primary"></i>English
                                    </span>
                                    <span class="mr-2">
                                        <i class="fas fa-circle text-success"></i> Science
                                    </span>
                                    <span class="mr-2">
                                        <i class="fas fa-circle text-info"></i> Maths
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <br>
                <br>
                <br>
                <!-- Successive Hurdle Race -->
                <div class="container" align="center">
                    <h1 id="h1" align="center" class="  text-light "><font style="font-size: 48px;"><b>Successive Hurdle Race 2</b></font>
                    </h1>
                    <h2 align="center" class="text-success"><font style="font-size: 70px;"><b>Winners</b>
                    </h2>
                    <div class="row" >
                        <div class="col " align="left">         
                            <div id="card5" class="card" style="width: 15rem;">
                                <img src="img/t1.jpg" class="card-img-top border border-3 shadow-sm" alt="...">
                                <div class="card-body border border-3 shadow-sm">
                                    <h5 class="card-title"><font style="color: black; font-size: 32px;">Chetanya Malhotra</font>
                                    </h5>
                                    <p class="card-text"><font style="color: black; font-size:25px">Manager Of The Year 2022</font>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col " align="left">         
                            <div id="card6" class="card" style="width: 15rem;">
                                <img src="img/t2.jpg" class="card-img-top border border-3 shadow-sm" alt="...">
                                <div class="card-body border border-3 shadow-sm">
                                    <h5 class="card-title"><font style="color: black; font-size: 32px;">Muskanpreet Kaur</font>
                                    </h5>
                                    <p class="card-text"><font style="color: black; font-size:25px">Executive Of The Year 2022</font>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col " align="left">         
                            <div id="card7" class="card" style="width: 15rem;">
                                <img src="img/t3.jpg" class="card-img-top border border-3 shadow-sm" alt="...">
                                <div class="card-body border border-3 shadow-sm">
                                    <h5 class="card-title"><font style="color: black; font-size: 32px;">Paramjeet Singh</font>
                                    </h5>
                                    <p class="card-text"><font style="color: black; font-size:25px">Officer Of The Year 2022</font>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

<!-- Footer -->

<a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



<!-- End of Footer -->
<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>
<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>
<!-- Page level custom scripts -->
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>
</body>
</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>