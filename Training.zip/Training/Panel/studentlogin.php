<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
</head>
<body style="background-color: #3CB371;">
    
<h1><a href="index.php"><button type="button" class="btn btn-dark border border-1 border-dark text-light float-end" style="text-align: right;">HOME</button></a></h1>
<br>
     <form action="login2.php" method="post" class="shadow-lg"  style="width:30%">
     	<h2 ><b>STUDENT  LOGIN</b></h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<label >Username</label>
     	<input  type="text" name="uname" placeholder="User Name" class="form-control " required><br>
     	<label>Password</label>
     	<input type="password" name="password" placeholder="Password" class="form-control" required><br>
     	<button type="submit" class=" btn btn-primary">Login</button>
     </form>
     <br>
     <p><b>Not Registered ? Register Now</b></p>
     	<a href="studentregister.php"><button type="submit" class="btn btn-dark" >Register</button></a>
</body>
</html>