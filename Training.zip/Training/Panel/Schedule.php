
<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Courses</title>
    <link rel="stylesheet" href="css/theme.css">

    <!-- My JS -->
    <script src="js/theme.js"></script>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" 
    rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="js/observers.js"></script>
 <style type="text/css">
     .black{
  position:fixed;
  top:0;
  background:#333;
  color: white;
  width:100%;
  height:50px;
  
}
.black ul{
  list-style-type:none;
  padding:0;
}

.black ul li{
  display:inline-block;
  width:100px;
  color:red;
}
.darkgrey {
  background-color:#282828;
}

.bg-green{
background-color: mediumseagreen;
}

.blue{
  position:fixed;
  top:0;
  background:blue;
  width:100%;
  height:50px;
}
 </style>
   <script>
$(document).ready(function(){
  $("#theme").click(function(){
    $("#mode").toggleClass("darkgrey");
    $("#mode").toggleClass("text-light");
    $("#ul").toggleClass("bg-dark");
    $("#theme").toggleClass("text-light");
    $("#active").toggleClass("bg-dark");
  });
});
</script>
<script src="js/theme.js"></script>
 <script type="text/javascript">
     
$(document).ready(function(){
  $(window).scroll(function(){
    var scroll = $(window).scrollTop();
      if (scroll > 150) {
        $(".black").css("background" , "Mediumseagreen");
      }

      else{
          $(".black").css("background" , "#333");   
      }
  })
})
 </script> 
 <!-- PreLoader -->
<style type="text/css">
    

.loader-container{
    width: 100%;
    height: 100vh;
    background-color: black;
    position: fixed;
    display: flex;
    align-items: center;
    justify-content: center;
}

.loader{
    width: 50px;
    height: 50px;
    border: 5px solid;
    color: #3498db;
    border-radius: 50%;
    border-top-color: transparent;
    animation: loader 5.2s linear infinite;
}

@keyframes loader{
    25%{
        color: #2ecc71;
    }
    50%{
        color: #f1c40f;
    }
    75%{
        color: #e74c3c;
    }
    to{
        transform: rotate(360deg);
    }
}
</style>
 <script>
        $(window).on("load",function(){
            $(".loader-container").fadeOut(2000);
        });
    </script>
</head>
<body id="page-top">
    <body id="page-top">
    <div class="loader-container">
        <div class="loader"></div>
    </div>
<!-- Page Wrapper -->
<div id="mode" class="darkgrey text-light" >
    <!-- Sidebar -->
    <ul id="ul" class="navbar-nav  bg-green bg-dark sidebar sidebar-dark accordion fixed-top" id="accordionSidebar">
        <!-- Sidebar - Brand -->
        <a  class="sidebar-brand d-flex align-items-center text-light  justify-content-center" href="panel.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3 ">
                <h5>Welcome</h5>
            </div>
        </a>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">
        <!-- Nav Item - Dashboard -->
        <li class="nav-item active"> 
            <a  class="nav-link " href="panel.php" >
                <i class="fas fa-fw fa-home" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Home</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Teachers.php">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span><font style="font-size: 18px;">Teachers</font></span>
            </a>
        </li>
        <li class="nav-item active"> 
            <a class="nav-link" href="Students.php">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Students</font>
                </span>
            </a>
        </li>
        <!-- Nav Item - Utilities Collapse Menu -->
        <li class="nav-item active">
            <a class="nav-link collapsed" href="Schedule.php" id="active"  style="background-color:mediumseagreen;" >
                <i class="fas fa-fw fa-calendar" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Schedule</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Courses.php">
                <i class="fas fa-fw fa-graduation-cap" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Courses</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <li class="nav-item active"> 
            <a class="nav-link" href="index.php">
                <i class="fas fa-fw fa-sign-out-alt" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Logout</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
    </ul>
    <!-- End of Sidebar -->
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="margin-left: 220px;">
    <!-- Main Content -->
    <!-- Topbar -->
        <nav class="navbar black fixed-top navbar-expand navbar-light topbar mb-4 static-top shadow" style="margin-left: 224px;"> 
                <ul>
                    <li><h3 align="left" class="text-light" style="width:1000px"><b>Admin Panel</b></h3></li>
                    <li style="margin-top:30px;"><h3 align="right" class="text-light" style="width:1000px"><font style="font-size:12px"><i id="theme" class="fas fa-sun fa-3x theme_icon "  ></i></font></h3>
                    </li>
                </ul>
                
            </nav>
    <br><br><br>
   
        <table border="2" class="table table-striped table-dark" align="center" style="width:95%; border-color: white;">
            <thead>
                <tr align="center">
                    <th scope="col" >Lecture</th>
                    <th scope="col">I</th>
                    <th scope="col">II</th>
                    <th scope="col">III</th>
                    <th scope="col">IV</th>
                    <th scope="col">V</th>
                    <th scope="col">Break</th>
                    <th scope="col">VI</th>
                    <th scope="col">VII</th>
                </tr>
            </thead>
            <tbody>
                <tr align="center">
                    <th scope="row"  >Time</th>
                    <td>9:15-10:00</td>
                    <td>10:00-10:45</td>
                    <td>10:45-11:30</td>
                    <td>11:30-12:15</td>
                    <td>12:15-1:00</td>
                    <td>1:00-1:30</td>
                    <td>1:30-2:15</td>
                    <td>2:15-3:00</td>
                </tr>
                <tr align="center">
                    <th scope="row" >MCA IV</th>
                    <td>Machine Learning And Data Analytics Using Python</td>
                    <td>Advanced Web Technologies</td>
                    <td>Cloud Computing</td>
                    <td colspan="2">Advanced Web Technologies(LAB)</td>
                    <td></td>
                    <td colspan="2">Project</td>
                    
                </tr>
                <tr align="center" >
                    <th scope="row" >MCA II</th>
                    <td>Web Technologies</td>
                    <td>Advanced Java</td>
                    <td>Info. Security</td>
                    <td>D.A.A.</td>
                    <td>Linux Administration</td>
                    <td></td>
                    <td colspan="2">Linux Administration Lab.</td>
                    
                </tr>
                <tr align="center">
                    <th scope="row" >BCA VI</th>
                    <td>Cloud Computing</td>
                    <td>Info. Security</td>
                    <td>Mentoring & PD</td>
                    <td colspan="2">Android Programming Lab</td>
                    <td></td>
                    <td>Digital Marketing</td>
                    <td>Android Programming</td>
                </tr >
                <tr align="center">
                    <th scope="row" >BCA IV</th>
                    <td>DBMS</td>
                    <td colspan="2">Operating Systems</td>
                    <td>S/W ENGG</td>
                    <td>OS</td>
                    <td></td>
                    <td>Web Designing</td>
                    <td></td>
                </tr>
                <tr align="center">
                    <th scope="row" >BCA II</th>
                    <td>Computer System Architecture</td>
                    <td>EVS</td>
                    <td>OOPS C++</td>
                    <td>Fundamental Of Statistics</td>
                    <td></td>
                    <td></td>
                    <td colspan="2">OOPS C++ Lab</td>
                </tr>
                <tr align="center">
                    <th scope="row" >MBA IV</th>
                    <td>IMC & SM</td>
                    <td>Int. Marketing</td>
                    <td>Corporate STGY</td>
                    <td>Indian Ethos</td>
                    <td>Beh. Fin Per. & Compen.MGT</td>
                    <td></td>
                    <td>Int. HRM/mergers & aqusitions</td>
                    <td></td>
                </tr>
                <tr align="center">
                    <th scope="row" >MBA II</th>
                    <td>Corp. Finance</td>
                    <td>Legal Env.</td>
                    <td>Mkting MGT.</td>
                    <td>Bus Analytics</td>
                    <td>HRM/Rnt.</td>
                    <td></td>
                    <td>POM</td>
                    <td>Computer Applications</td>
                </tr>
                <tr align="center">
                    <th scope="row" >BBA VI</th>
                    <td>Strategy MGT.</td>
                    <td>Service Mkting</td>
                    <td>Mentoring & PD</td>
                    <td>Retailing & Logistics</td>
                    <td>Company Law</td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr align="center">
                    <th scope="row" >BBA IV</th>
                    <td>Ent.</td>
                    <td>Bus. Research Methods</td>
                    <td>HRM</td>
                    <td>BE & CSR</td>
                    <td></td>
                    <td>FM</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr align="center">
                    <th scope="row" >BBA II</th>
                    <td>EVS</td>
                    <td>Business Stats</td>
                    <td></td>
                    <td>Managerial Eco</td>
                    <td>Bus. Env</td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr align="center">
                    <th scope="row" >B.Com VI</th>
                    <td>Banking Law & Services</td>
                    <td>OR</td>
                    <td>Mentoring & PD</td>
                    <td>Risk & Insurance MGT</td>
                    <td>IR & LL</td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr align="center">
                    <th scope="row" >B.Com IV</th>
                    <td>ENT></td>
                    <td>Income Tax Law</td>
                    <td>Company Law</td>
                    <td>Corporate Acc</td>
                    <td>Workshop On Computerized Acc.</td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr align="center">
                    <th scope="row" >B.Com II</th>
                    <td>Bus. Stats</td>
                    <td>Cost Acc</td>
                    <td>EVS</td>
                    <td>BE</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>
<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>
<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>
<!-- Page level custom scripts -->
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>
</body>
</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>