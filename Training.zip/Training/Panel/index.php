<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Index</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
  <style>
    	body{
					  width: 100%;
				  	min-height: 100vh;
				  	background: linear-gradient(
				    to right,
				    MediumSeaGreen 0%,
				    MediumSeaGreen 50%,
				    Whitesmoke 50%,
				    Whitesmoke 100%
				  );
  					justify-content: center;
  					align-items: center;
					}
    </style>
</head>
<body>
	<div class="row" align="center" style="margin-top: 20%;">
		<div class="col" align="center">
			<h1>
				<b><font style="font-size: 70px;color: white;">ADMIN</font></b>
			</h1>
			<br>
			<a href="adminlogin.php">
				<button type="button" class="btn btn-dark">Login As Admin
				</button>
			</a>
		</div>
		<div class="col" align="center">
			<h1>
				<b><font style="font-size: 70px;color: mediumseagreen;">STUDENT</font></b>
			</h1>
			<br>
			<a href="studentlogin.php">
				<button type="button" class="btn btn-dark" >Log In As Student
				</button>
			</a>
		</div>
	</div>
</body>
</html>