<?php  
$connect = mysqli_connect("localhost", "root", "", "admin");
$sql = "INSERT INTO student(fname, lname,course,contact,createdDate) VALUES('".$_POST["fname"]."', '".$_POST["lname"]."', '".$_POST["course"]."', '".$_POST["contact"]."',now())";  
if(mysqli_query($connect, $sql))  
{  
     echo 'Data Inserted';  
}  
 ?>