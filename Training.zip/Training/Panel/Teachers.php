
<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Teachers</title>

    <!-- CSS FILES  -->

    <link rel="stylesheet" href="css/theme.css">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" 
    rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="extensions/sticky-header/bootstrap-table-sticky-header.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">

    <!-- JAVASCRIPT FILES  -->

    <script src="js/theme.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="js/observers.js"></script>
    <script src="js/theme.js"></script>
    <script src="extensions/sticky-header/bootstrap-table-sticky-header.js"></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

    <!-- SCRIPTING  -->

    <script>
        $(document).ready(function(){
          $("#theme").click(function(){
            $("#mode").toggleClass("darkgrey");
            $("#mode").toggleClass("text-light");
            $("#ul").toggleClass("bg-dark");
            $("#theme").toggleClass("text-light");
            $("#active").toggleClass("bg-dark");
          });
        });
    </script>
    <script >
        $(document).ready(function(){
          $(window).scroll(function(){
            var scroll = $(window).scrollTop();
              if (scroll > 150) {
                $(".black").css("background" , "Mediumseagreen");
              }
              else{
                  $(".black").css("background" , "#333");   
              }
          })
        })
    </script>
    <script>
        $(window).on("load",function(){
            $(".loader-container").fadeOut(2000);
        });
    </script>

<!--  STYLING -->

    <style>
        .black{
            position:fixed;
            top:0;
            background:#333;
            color: white;
            width:100%;
            height:50px;
        }
        .darkgrey {
            background-color:#282828;
        }
        .bg-green{
            background-color: mediumseagreen;
        }
        .black ul{
            list-style-type:none;
            padding:0;
        }
        .black ul li{
            display:inline-block;
            width:100px;
            color:red;
        }
        .blue{
            position:fixed;
            top:0;
            background:blue;
            width:100%;
            height:50px;
        }
        .loader-container{
            width: 100%;
            height: 100vh;
            background-color: black;
            position: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .loader{
            width: 50px;
            height: 50px;
            border: 5px solid;
            color: #3498db;
            border-radius: 50%;
            border-top-color: transparent;
            animation: loader 5.2s linear infinite;
        }
        @keyframes loader{
            25%{
                color: #2ecc71;
            }
            50%{
                color: #f1c40f;
            }
            75%{
                color: #e74c3c;
            }
            to{
                transform: rotate(360deg);
            }
        }
    </style>
</head>
<body id="page-top">
    <div class="loader-container">
        <div class="loader"></div>
    </div>
<!-- Page Wrapper -->
<div id="mode" class="darkgrey text-light"  >
    <!-- Sidebar -->
    <ul id="ul" class="navbar-nav  bg-green bg-dark sidebar sidebar-dark accordion fixed-top" id="accordionSidebar">
        <!-- Sidebar - Brand -->
        <a  class="sidebar-brand d-flex align-items-center text-light  justify-content-center" href="panel.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3 ">
                <h5>Welcome</h5>
            </div>
        </a>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">
        <!-- Nav Item - Dashboard -->
        <li class="nav-item active"> 
            <a  class="nav-link " href="panel.php" >
                <i class="fas fa-fw fa-home" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Home</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Teachers.php" id="active"  style="background-color:mediumseagreen;">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span><font style="font-size: 18px;">Teachers</font></span>
            </a>
        </li>
        <li class="nav-item active"> 
            <a class="nav-link" href="Students.php">
                <i class="fas fa-fw fa-user" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Students</font>
                </span>
            </a>
        </li>
        <!-- Nav Item - Utilities Collapse Menu -->
        <li class="nav-item active">
            <a class="nav-link collapsed" href="Schedule.php" >
                <i class="fas fa-fw fa-calendar" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Schedule</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <!-- Heading -->
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active"> 
            <a class="nav-link" href="Courses.php">
                <i class="fas fa-fw fa-graduation-cap" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Courses</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider">
        <li class="nav-item active"> 
            <a class="nav-link" href="index.php">
                <i class="fas fa-fw fa-sign-out-alt" style="font-size:20px"></i>
                <span>
                    <font style="font-size: 18px;">Logout</font>
                </span>
            </a>
        </li>
        <!-- Divider -->
    </ul>
    <!-- End of Sidebar -->
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="margin-left: 220px;">
    <!-- Main Content -->
    <!-- Topbar -->
     <nav class="navbar black fixed-top navbar-expand navbar-light topbar mb-4 static-top shadow" style="margin-left: 224px;"> 
                <ul>
                    <li><h3 align="left" class="text-light" style="width:1000px"><b>Admin Panel</b></h3></li>
                    <li style="margin-top:30px;"><h3 align="right" class="text-light" style="width:1000px"><font style="font-size:12px"><i id="theme" class="fas fa-sun fa-3x theme_icon "  ></i></font></h3>
                    </li>
                </ul>
                
            </nav>
<br><br><br>
<div class="container">
    <div>
        <h2 align="center" style="color: mediumseagreen;"><b>Management Faculty</b></h2>
        <br>
        <table class="table table-info text-dark" align="center">
            <thead>
                <tr align="center">
                    <th scope="col" >#</th>
                    <th scope="col" >Name</th>
                    <th scope="col">Designation</th>
                    <th scope="col">Qualification</th>
                    <th scope="col">Email</th>
                    <th scope="col">Picture</th>
                </tr>
            </thead>
            <tbody>
                <tr align="center">
                    <th>1.</th>
                    <td scope="row" >Dr. Upinder Kaur</td>
                    <td >Associate Professor </td>
                    <td>Ph.D(Stat), M.Phill.,M.Sc.(Math)    </td>
                    <td>upinderkaur@gnimt.org   </td>
                    <td><img src="img/f1.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>2.</th>
                    <td scope="row">Dr. Rajni Sofat </td>
                    <td>Associate Professor </td>
                    <td>Ph.D, M.Com., M.Phil(UGC)   </td>
                    <td> rajnisofatr@gnimt.org  </td>
                    <td><img src="img/f2.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>3.</th>
                    <td scope="row">Dr. Ramneek Kaur    </td>
                    <td>Associate Professor </td>
                    <td>Ph.D,M.Phil, MBA, M.Com.    </td>
                    <td>ramneekkaur@gnimt.org   </td>
                    <td><img src="img/f3.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>4.</th>
                    <td scope="row">Dr. Inderpreet Kaur </td>
                    <td>Associate Professor </td>
                    <td>Ph.D, MBA(Marketing)    </td>
                    <td>inderpreetkaur@gnimt.org    </td>
                    <td><img src="img/f4.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>5.</th>
                    <td scope="row">Dr. Sandeep Kaur    </td>
                    <td>Associate Professor </td>
                    <td>Ph.D,M.Sc.(Math), M.Ed., Dip in Statistics  </td>
                    <td>sandeepkaur@gnimt.org   </td>
                    <td><img src="img/f5.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>6.</th>
                    <td scope="row">Dr. Rajan Sidhar    </td>
                    <td>Associate Professor </td>
                    <td>  Ph.D, MBA(Marketing)  </td>
                    <td> rajansridhar@gnimt.org </td>
                    <td><img src="img/f6.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>7.</th>
                    <td scope="row">Dr. Amanpreet Singh Brar    </td>
                    <td>Associate Professor </td>
                    <td>Ph.D, MBA(Marketing)    </td>
                    <td> amanpreetbrar@gnimt.org    </td>
                    <td><img src="img/f7.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>8.</th>
                    <td scope="row">Dr. Sunpreet Kaur   </td>
                    <td>Associate Professor </td>
                    <td>Ph.D,MBA, PGDCA, PGDM   </td>
                    <td> sunpreetkaur@gnimt.org </td>
                    <td><img src="img/f8.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>9.</th>
                    <td scope="row">Dr. Munish Kapila   </td>
                    <td>Associate Professor </td>
                    <td>Ph.D, M.Com UGC NET </td>
                    <td> munishkapila@gnimt.org </td>
                    <td><img src="img/f9.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>10.</th>
                    <td scope="row">Dr. Nidhi Sharma    </td>
                    <td>Assistant Professor </td>
                    <td>Ph.D, MBA   </td>
                    <td> nidhisharma@gnimt.org  </td>
                    <td><img src="img/f10.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                
                <tr align="center">
                    <th>11.</th>
                    <td scope="row">Dr. Ramandeep Kaur  </td>
                    <td>Assistant Professor </td>
                    <td>Ph.D, MBA(Marketing)</td>
                    <td>ramandeepkaur@gnimt.org </td>
                    <td><img src="img/f11.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>

            </tbody>
        </table>
    </div>
    <div>
        <h2 align="center" style="color: mediumseagreen;"><b>Computer Science Faculty</b></h2>
        <br>
        <table class="table table-success text-dark" align="center">
            <thead>
                <tr align="center">
                    <th scope="col" >#</th>
                    <th scope="col" >Name</th>
                    <th scope="col">Designation</th>
                    <th scope="col">Qualification</th>
                    <th scope="col">Email</th>
                    <th scope="col">Picture</th>
                </tr>
            </thead>
            <tbody>
                <tr align="center">
                    <th>1.</th>
                    <td scope="row">Dr. Anjali Garg </td>
                    <td>Associate Professor </td>
                    <td>Ph.D, MCA, MFC Comp,    /td>
                    <td>anjaligarg@gnimt.org    </td>
                    <td><img src="img/cf1.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>2.</th>
                    <td scope="row">Dr. Balvinder Taneja    </td>
                    <td>Associate Professor </td>
                    <td>Ph.D, MCA,MBA   </td>
                    <td> btaneja@gnimt.org  </td>
                    <td><img src="img/cf2.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>3.</th>
                    <td scope="row">Dr. Harsimerjit Khurana </td>
                    <td>Associate Professor </td>
                    <td>Ph.D, MCM-Comp. & MBA   </td>
                    <td>hkhurana@gnimt.org  </td>
                    <td><img src="img/cf3.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>4.</th>
                    <td scope="row">Er. Ram Raghunandan </td>
                    <td>Assistant Professor </td>
                    <td>B.Tech(CSE), PGDBM, MBA </td>
                    <td>ramr@gnimt.org  </td>
                    <td><img src="img/cf4.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>5.</th>
                    <td scope="row">Dr. Tripatdeep Singh    </td>
                    <td>Associate Professor </td>
                    <td>Ph.D, MCA, MCSE </td>
                    <td>tripatdeepsingh@gnimt.org   </td>
                    <td><img src="img/cf5.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>6.</th>
                    <td scope="row">Mr. Ravinder Singh  </td>
                    <td>Assistant Professor </td>
                    <td>MCA </td>
                    <td>ravindersingh@gnimt.org </td>
                    <td><img src="img/cf6.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>
                <tr align="center">
                    <th>7.</th>
                    <td scope="row">Ms. Amanpreet Kaur  </td>
                    <td>Assistant Professor </td>
                    <td>M.Phil, MCA </td>
                    <td>amanpreetkaur@gnimt.org </td>
                    <td><img src="img/cf7.jpg" height="100px" width="75px" class="rounded mx-auto d-block"></td>
                </tr>

            </tbody>
        </table>
    </div>
</div>
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

</body>
</html>
<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>