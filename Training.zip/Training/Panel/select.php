<?php  
 $connect = mysqli_connect("localhost", "root", "", "admin");  
 $output = '';  
 $sql = "SELECT * FROM student ORDER BY id DESC";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div class="table-responsive">  
           <table  class="table table-bordered table-success text-dark table-striped" >  
                <tr>  
                     <th >ID</th>  
                     <th >First Name</th>  
                     <th >Last Name</th> 
                     <th >Course</th>
                     <th >Contact</th>
                     <th >Created On</th>
                     <th >Delete</th>  
                </tr>';  
 $rows = mysqli_num_rows($result);
 if($rows > 0)  
 {  
       if($rows > 10)
       {
            $delete_records = $rows - 10;
            $delete_sql = "DELETE FROM student LIMIT $delete_records";
            mysqli_query($connect, $delete_sql);
       }
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td>'.$row["id"].'</td>  
                     <td class="fname" data-id1="'.$row["id"].'" contenteditable>'.$row["fname"].'</td>  
                     <td class="lname" data-id2="'.$row["id"].'" contenteditable>'.$row["lname"].'</td> 
                      <td class="course" data-id3="'.$row["id"].'" contenteditable>'.$row["course"].'</td>
                       <td class="contact" data-id4="'.$row["id"].'" contenteditable>'.$row["contact"].'</td>
                       <td class="contact" >'.$row["createdDate"].'</td>

                     <td><button type="button" name="delete_btn" data-id5="'.$row["id"].'" class="btn  btn-danger btn_delete">Delete</button></td>  
                </tr>  
           ';  
      }  
      $output .= '  
           <tr>  
                <td></td>  
                <td id="fname" contenteditable></td>  
                <td id="lname" contenteditable></td>
                <td id="course" contenteditable></td>
                <td id="contact" contenteditable></td>  
                 
           </tr>  
      ';  
 }  
 else  
 {  
      $output .= '
                    <tr>  
                         <td></td>  
                         <td id="fname" contenteditable></td>  
                         <td id="lname" contenteditable></td>
                         <td id="course" contenteditable></td>
                         <td id="contact" contenteditable></td>  
                          
                  </tr>';  
 }  
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>