<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title> Sign up / Login Form</title>
  <link rel="stylesheet" href="./signup.css">
<link rel="icon" type="image/png" href="Images/logo.png">
</head>
<body>
<!-- partial:index.partial.html -->
<!DOCTYPE html>
<html>
<head>
	<title>Slide Navbar</title>
	<link rel="stylesheet" type="text/css" href="slide navbar style.css">
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
</head>
<body>
	ss
	<div class="main">  	
		<input type="checkbox" id="chk" aria-hidden="true">

			<div class="signup">
				<form action="insertcode.php">
					<label for="chk" aria-hidden="true">Sign up</label>
					<input type="text" name="fname" placeholder="Enter First Name" required="">
					<input type="text" name="lname" placeholder="Enter Last Name" required="">
					<input type="text" name="course" placeholder="Enter Course" required="">
					<input type="number" name="contact" class="form-control" placeholder="Enter Phone Number" required="">
					<button>Sign up</button>
				</form>
			</div>

			<div class="login">
				<form>
					<label for="chk" aria-hidden="true">Login</label>
					<input type="email" name="email" placeholder="Email" required="">
					<input type="password" name="pswd" placeholder="Password" required="">
					<button>Login</button>
				</form>
			</div>
	</div>
</body>
</html>
<!-- partial -->
  
</body>
</html>
